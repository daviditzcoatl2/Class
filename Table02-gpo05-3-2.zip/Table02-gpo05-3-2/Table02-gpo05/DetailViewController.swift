//
//  DetailViewController.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

struct Total{
    var total: Double
    var prod: [String]
    var cant: [Int]
}

var totalventas: [Total] = []

class DetailViewController: UIViewController {
    @IBOutlet weak var imagenDetail: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var descriptioen: UILabel!
    // var productos: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = panes[IndexP].nombre
        imagenDetail.image = UIImage(named: panes[IndexP].imagen )
        descriptioen.text = panes[IndexP].desc
        
    }

    @IBAction func Comprar(_ sender: UIButton) {
        
        //var compraClosure
        
        let optionMenu = UIAlertController(title: "¿Deseas comprar?", message: panes[IndexP].nombre, preferredStyle: .alert)
        
        let yesAction = UIAlertAction(title: "Sí", style: .default, handler: nil)
        
        let noAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        
        optionMenu.addAction(yesAction)
        optionMenu.addAction(noAction)
        
        present(optionMenu, animated: true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

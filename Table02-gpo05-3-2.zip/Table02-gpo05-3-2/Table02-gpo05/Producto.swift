//
//  Producto.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var precio: Double
    var imagen: String
}
var IndexP = 0 //variable para acceder a las propiedades de cualquier elemento
                //del arreglo panes en cuanquier controlador

let brownies = Producto(nombre: "Brownies",
                        desc: "Delicioso pan de chocolate",
                        precio: 2.50,
                        imagen: "brownies")
let bagels = Producto(nombre: "Bagels",
                      desc: "Producto muy parecido a las donas",
                      precio: 4.50,
                      imagen: "bagels")
let butter = Producto(nombre: "Mantequilla",
                      desc: "Producto elaborado con grasa vegetal",
                      precio: 12.00,
                      imagen: "butter")

var panes = [brownies,bagels,butter]



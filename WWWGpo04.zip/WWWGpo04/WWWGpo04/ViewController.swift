//
//  ViewController.swift
//  WWWGpo04
//
//  Created by MacBook on 30/04/18.
//  Copyright © 2018 David. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = UIColor.blue
        getTracks()
    }
    
    func getTracks(){
        let url = "http://itunes.apple.com/search?term=imaginedragons"
        Alamofire.request(url).responseData { (dataResponce) in
            if let error = dataResponce.error{
                print("Hay un error:", error)
            }
            guard let data = dataResponce.data else { return }
            let testString = String(data: data, encoding: .utf8)
            print(testString)
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

